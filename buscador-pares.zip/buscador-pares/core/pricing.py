"""Cálculo de precio final: precio - mejor cupón + envío, convertido a MXN.

Envío: reglas por tienda (umbral de gratis / tarifa plana) hacia el CP destino
fijo (90021 USA, 44240 MX). Cotización en vivo por CP requiere automatizar el
checkout de cada tienda (frágil); las reglas cubren el 95% de los casos y son
editables en stores.yaml.
"""
from .config import StoreCfg, Coupon


def best_coupon(price: float, store_key: str, coupons: list[Coupon]):
    best, best_discount = None, 0.0
    for c in coupons:
        if c.store != store_key or price < c.min_purchase:
            continue
        d = price * c.value / 100.0 if c.kind == "percent" else min(c.value, price)
        if d > best_discount:
            best, best_discount = c, d
    return best, round(best_discount, 2)


def shipping_cost(subtotal: float, store: StoreCfg) -> float:
    rules = store.shipping or {}
    free_over = rules.get("free_over", None)
    flat = float(rules.get("flat", 0) or 0)
    if free_over is not None and subtotal >= float(free_over):
        return 0.0
    return flat


def compute_landed(listing: dict, store: StoreCfg, coupons: list[Coupon], fx_usd_mxn: float) -> dict:
    price = float(listing["price"])
    coupon, discount = best_coupon(price, store.key, coupons)
    subtotal = round(price - discount, 2)
    ship = shipping_cost(subtotal, store)
    total = round(subtotal + ship, 2)
    total_mxn = round(total * fx_usd_mxn, 2) if store.currency == "USD" else total
    out = dict(listing)
    out.update({
        "store_key": store.key,
        "store_name": store.name,
        "country": store.country,
        "currency": store.currency,
        "discount": discount,
        "coupon_code": coupon.code if coupon else None,
        "shipping": ship,
        "total": total,
        "total_mxn": total_mxn,
        "on_sale": bool(listing.get("list_price") and float(listing["list_price"]) > price),
    })
    return out
