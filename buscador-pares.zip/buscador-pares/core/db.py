"""SQLite: watchlist e historial de precios (para detectar bajadas)."""
import sqlite3
import time
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS watchlist (
    id INTEGER PRIMARY KEY,
    query TEXT NOT NULL,
    note TEXT DEFAULT '',
    active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS price_history (
    id INTEGER PRIMARY KEY,
    ts INTEGER NOT NULL,
    query TEXT NOT NULL,
    store_key TEXT NOT NULL,
    title TEXT,
    sku TEXT,
    url TEXT,
    price REAL,
    total REAL,
    total_mxn REAL,
    currency TEXT
);
CREATE INDEX IF NOT EXISTS idx_hist ON price_history(query, store_key, ts);
"""

SEED_WATCHLIST = [
    ("on cloudmonster", "Watch constante"),
    ("birkenstock boston", "Watch constante"),
    ("veja campo", "Watch constante"),
    ("new balance 9060", "Watch constante"),
]


def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init():
    c = conn()
    c.executescript(SCHEMA)
    n = c.execute("SELECT COUNT(*) FROM watchlist").fetchone()[0]
    if n == 0:
        c.executemany("INSERT INTO watchlist(query, note) VALUES (?, ?)", SEED_WATCHLIST)
    c.commit()
    c.close()


def get_watchlist():
    c = conn()
    rows = [dict(r) for r in c.execute("SELECT * FROM watchlist WHERE active=1 ORDER BY id")]
    c.close()
    return rows


def add_watch(query: str, note: str = ""):
    c = conn()
    c.execute("INSERT INTO watchlist(query, note) VALUES (?, ?)", (query, note))
    c.commit(); c.close()


def remove_watch(wid: int):
    c = conn()
    c.execute("UPDATE watchlist SET active=0 WHERE id=?", (wid,))
    c.commit(); c.close()


def save_snapshot(query: str, listings: list[dict]):
    c = conn()
    ts = int(time.time())
    c.executemany(
        "INSERT INTO price_history(ts, query, store_key, title, sku, url, price, total, total_mxn, currency)"
        " VALUES (?,?,?,?,?,?,?,?,?,?)",
        [(ts, query, l["store_key"], l["title"], l.get("sku"), l.get("url"),
          l["price"], l["total"], l["total_mxn"], l["currency"]) for l in listings])
    c.commit(); c.close()


def last_best_total_mxn(query: str) -> float | None:
    """Mejor total (MXN) del snapshot anterior de esta búsqueda."""
    c = conn()
    row = c.execute("SELECT MAX(ts) FROM price_history WHERE query=?", (query,)).fetchone()
    if not row or not row[0]:
        c.close(); return None
    last_ts = row[0]
    row = c.execute(
        "SELECT MIN(total_mxn) FROM price_history WHERE query=? AND ts=?",
        (query, last_ts)).fetchone()
    c.close()
    return row[0] if row else None


def history(query: str, limit: int = 500):
    c = conn()
    rows = [dict(r) for r in c.execute(
        "SELECT * FROM price_history WHERE query=? ORDER BY ts DESC LIMIT ?", (query, limit))]
    c.close()
    return rows
