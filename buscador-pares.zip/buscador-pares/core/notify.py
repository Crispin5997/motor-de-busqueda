"""Alertas a Discord (mismo esquema de webhook que el monitor de drops)."""
import httpx


def discord(webhook_url: str, message: str):
    if not webhook_url:
        return
    try:
        httpx.post(webhook_url, json={"content": message}, timeout=10)
    except Exception:
        pass  # una alerta fallida no debe tumbar el refresh
