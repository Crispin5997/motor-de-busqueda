"""Referencia de mercado: StockX y GOAT (rango de precios de reventa).

Ambos tienen anti-bot fuerte (PerimeterX/Cloudflare). Desde IP residencial
a veces responden; si bloquean, la app lo indica y sigue funcionando.
GOAT históricamente expone búsqueda vía Algolia con llave pública, que es
la ruta más estable de las dos.
"""
from stores.base import stealth_client


async def stockx(query: str, timeout: float = 10, cookie: str = "") -> dict:
    try:
        headers = {"Accept": "application/json", "Referer": "https://stockx.com/"}
        if cookie:
            headers["Cookie"] = cookie
        async with stealth_client(headers, timeout) as c:
            r = await c.get("https://stockx.com/api/browse",
                            params={"_search": query, "page": 1, "resultsPerPage": 5})
            if r.status_code != 200:
                return {"status": "bloqueada", "items": []}
            data = r.json()
            items = []
            for p in (data.get("Products") or [])[:5]:
                items.append({
                    "title": p.get("title"),
                    "sku": p.get("styleId"),
                    "lowest_ask": (p.get("market") or {}).get("lowestAsk"),
                    "last_sale": (p.get("market") or {}).get("lastSale"),
                    "url": "https://stockx.com/" + (p.get("urlKey") or ""),
                })
            return {"status": "ok", "items": items}
    except Exception as e:
        return {"status": f"error: {type(e).__name__}", "items": []}


async def goat(query: str, timeout: float = 10) -> dict:
    try:
        async with stealth_client({
            "x-algolia-application-id": "2FWOTDVM2O",
            "x-algolia-api-key": "ac96de6fef0e02bb95d433d8d5c7038a",
        }, timeout) as c:
            r = await c.post(
                "https://2fwotdvm2o-dsn.algolia.net/1/indexes/product_variants_v2/query",
                json={"params": f"query={query}&hitsPerPage=5"})
            if r.status_code != 200:
                return {"status": "bloqueada", "items": []}
            hits = r.json().get("hits", [])
            items = []
            for h in hits[:5]:
                lp = h.get("lowest_price_cents")
                items.append({
                    "title": h.get("name"),
                    "sku": h.get("sku"),
                    "lowest_ask": (lp / 100.0) if lp else None,
                    "last_sale": None,
                    "url": "https://www.goat.com/sneakers/" + (h.get("slug") or ""),
                })
            return {"status": "ok", "items": items}
    except Exception as e:
        return {"status": f"error: {type(e).__name__}", "items": []}
