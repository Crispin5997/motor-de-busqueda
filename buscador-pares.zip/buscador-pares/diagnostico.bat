@echo off
cd /d "%~dp0"
title PARES - Diagnostico
echo ================ DIAGNOSTICO ================
echo Carpeta actual: %CD%
echo.
echo [1] Archivos que deben existir aqui:
for %%F in (app.py requirements.txt config\stores.yaml static\index.html) do (
  if exist "%%F" (echo   OK  %%F) else (echo   FALTA %%F  ^<-- problema)
)
echo.
echo [2] Python...
where python 2>nul
where py 2>nul
where python >nul 2>nul && (set PY=python) || (set PY=py)
%PY% --version 2>nul || echo   FALTA: instalar Python de python.org marcando "Add to PATH"
echo.
echo [3] Dependencias...
%PY% -c "import fastapi, uvicorn, httpx, rapidfuzz, yaml; print('   OK dependencias base')" 2>nul || echo   FALTA: correr instalar.bat
%PY% -c "from curl_cffi.requests import AsyncSession; print('   OK curl_cffi (huella Chrome real)')" 2>nul || echo   FALTA curl_cffi (correr instalar.bat de nuevo)
echo.
echo [4] Puerto 8712...
netstat -ano | findstr :8712 || echo   Libre (el servidor no esta corriendo)
echo.
echo Toma foto de esta ventana y mandala a Claude si algo marca FALTA.
echo =============================================
pause
